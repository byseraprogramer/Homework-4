package com.example.demo.service.impl;

import com.example.demo.model.CompanyDataTransaction;
import com.example.demo.model.CompanyDataTransaction;
import com.example.demo.repository.CompanyDataTransactionRepository;
import com.example.demo.repository.CompanyDataTransactionRepository;
import com.example.demo.service.CompanyDataTransactionService;
import com.example.demo.service.CompanyDataTransactionService;
import org.hibernate.annotations.Fetch;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class CompanyDataTransactionServiceImpl implements CompanyDataTransactionService {
    @Autowired
    private CompanyDataTransactionRepository companyTransactionRepository;

    @Override
    public List<CompanyDataTransaction> getAllData() {
        return companyTransactionRepository.findAll();
    }

    @Override
    public CompanyDataTransaction getDataById(Long id) {
        return companyTransactionRepository.findById(id).orElse(null);
    }
}